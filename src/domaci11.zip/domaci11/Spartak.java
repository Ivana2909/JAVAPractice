package domaci11;

import java.util.ArrayList;

public class Spartak extends SportskiKlub{

    public Spartak(ArrayList<Sportista> sportista, String gradKluba, double budzet) {
        super(sportista, gradKluba, budzet);
    }


    @Override
    public String toString() {
        return super.toString();

    }
}
