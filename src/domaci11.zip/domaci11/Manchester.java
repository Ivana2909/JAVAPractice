package domaci11;

import java.util.ArrayList;

public class Manchester extends SportskiKlub{

    public Manchester(ArrayList<Sportista> sportista, String gradKluba, double budzet) {
        super(sportista, gradKluba, budzet);
    }
    @Override
    public String toString() {
        return super.toString();

    }
}
