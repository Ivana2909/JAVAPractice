package domaci11;

import java.util.ArrayList;

public class Arsenal extends SportskiKlub{

    public Arsenal(ArrayList<Sportista> sportista, String gradKluba, double budzet) {
        super(sportista, gradKluba, budzet);
    }
    @Override
    public String toString() {
        return super.toString();

    }
}
