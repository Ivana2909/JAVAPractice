package domaci13;

public interface Planinarenje {
    void popniSe(Planina p);
    double clanarina();
    double sviUsponi();
    double najvecaPlanina();


}
